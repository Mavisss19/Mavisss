import Link from 'next/link';

const Navbar = () => (
    <nav className="bg-blue-500 text-white p-4">
        <div className="container mx-auto flex justify-between items-center">
            <h1 className="text-xl font-bold">MTSN 01 Library</h1>
            <ul className="flex space-x-4">
                <li><Link href="/">Beranda</Link></li>
                <li><Link href="/books">Katalog Buku</Link></li>
                <li><Link href="/news">Berita</Link></li>
                <li><Link href="/about">Tentang Kami</Link></li>
                <li><Link href="/contact">Kontak</Link></li>
            </ul>
        </div>
    </nav>
);

export default Navbar;