const BookCard = ({ book }) => (
    <div className="p-4 border rounded shadow-md">
        <h3 className="text-lg font-bold">{book.title}</h3>
        <p className="text-gray-600">Author: {book.author}</p>
        <p className="text-gray-600">Year: {book.year}</p>
    </div>
);

export default BookCard;