import BookCard from '../../components/BookCard';

const Books = ({ books }) => (
    <div className="container mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold mb-4">Katalog Buku</h1>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {books.map((book) => (
                <BookCard key={book.id} book={book} />
            ))}
        </div>
    </div>
);

export async function getStaticProps() {
    const books = require('../../public/books.json');
    return {
        props: { books },
    };
}

export default Books;