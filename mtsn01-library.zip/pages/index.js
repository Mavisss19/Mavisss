import Layout from '../components/Layout';

export default function Home() {
    return (
        <Layout>
            <div className="container mx-auto px-4 py-6">
                <h1 className="text-3xl font-bold text-center mb-4">Selamat Datang di Perpustakaan MTSN 01 Kota Bengkulu!</h1>
                <p className="text-center">Temukan berbagai koleksi buku dan informasi terbaru di sini.</p>
            </div>
        </Layout>
    );
}